/*! grafana - v1.9.1 - 2014-12-29
 * Copyright (c) 2014 Torkel Ödegaard; Licensed Apache License */

define(["helpers","controllers/row"],function(a){describe("RowCtrl",function(){var b=new a.ControllerTestContext;beforeEach(module("grafana.controllers")),beforeEach(b.providePhase()),beforeEach(b.createControllerPhase("RowCtrl"))})});